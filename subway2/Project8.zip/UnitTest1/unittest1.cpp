#include "stdafx.h"
#include "CppUnitTest.h"
#include "..\Project8\city.h"
#include <Windows.h>
#define PATH "f:\\beijing-subway(1).txt"
using namespace Microsoft::VisualStudio::CppUnitTestFramework;
using namespace std;
namespace UnitTest1
{		
	TEST_CLASS(UnitTest1)
	{
	public:
		//test str2id
		TEST_METHOD(TestMethod1)
		{
			City *ct;// = new City(PATH);
			Errortype E(1);
			////city.readmap(PATH);
			//Assert::AreEqual(1, ct->str2id("ƻ��԰"));
		}

		/*TEST_METHOD(TestMethod2)
		{
			City city;
			city.readmap(PATH);
			Assert::AreEqual(-1, city.str2id("as"));
		}

		TEST_METHOD(TestMethod3)
		{
			City city;
			city.readmap(PATH);
			Assert::AreEqual(-1, city.str2id(NULL));
		}

		TEST_METHOD(TestMethod4)
		{
			City city;
			city.readmap(PATH);
			Assert::AreEqual(-1, city.str2id(""));
		}

*/
/*
		TEST_METHOD(TestMethod2)
		{

		}
*/

	};
}