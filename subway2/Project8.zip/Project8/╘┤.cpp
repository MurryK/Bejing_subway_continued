#include<windows.h>  
#include <fstream>
#include <iostream>
#include"city.h"
#pragma warning (disable : 4996)
#define MAXX 1370
#define MAXY 710
#define RMENU 150
#define POPMENU1 200
#define POPMENU2 201
#define FILEMENU 202
#define IMPORTMENU 203
using namespace std;
City bj;
int xChar, yChar;
double bigger;
int mx, my;
int seektime;
int expandid;
int useful;
RECT rc;
Point p = { 0,0 };
Point seekedsta = { 0,0 };
int choosedsta,bg_sta,ed_sta,seek_sta;
int way[100];
int colors[20][3] = { {204,0,0},{0,102,204},{0,204,204},{153,0,102},{234,153,20},{231,96,14},{0,102,51},{173,203,19},{0,135,255} ,
					{245,207,92},{ 211,145,136} ,{92,42,105},{ 204,0,0 },{ 196,0,130 } ,{ 255,55,3 },{ 213,53,63 },{ 182,153,189} };
void DrawSta(HDC hdc);
void DrawLine(HDC hdc);
void paintway(HDC hdc, int *way);
void findway(char *s1, char *s2, int type);
HMENU createPopMenu(HWND hwnd);
HMENU createmainMenu(HWND hwnd);
Point point2point(int x, int y);
int seek(char *s);
void paintsta(HDC hdc);
void printsta(HDC hdc);
DWORD WINAPI flash(LPVOID pM);
void fillprintrect(HWND hwnd);
LRESULT CALLBACK WinSunProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	HDC hdc;
	int num_bg, num_ed, num;
	char s1[30],s2[30];
	POINT pt;
	HMENU hTrack, hSon;
	PAINTSTRUCT ps;
	static HPEN pen = CreatePen(PS_SOLID, 5, RGB(255, 50, 70));
	static HBRUSH brush = CreateSolidBrush(RGB(50, 255, 70));
	static HWND button1, button2, label1, label2, edit_bg, edit_ed,button_big,button_small,edit_seek,label_seek,button_seek, hwndScroll;
	static HMENU hmenu;
	static HFONT hFont = CreateFont(-13, -6, 0, 0, 400,
		FALSE/*б��?*/, FALSE/*�»���?*/, FALSE/*ɾ����?*/, DEFAULT_CHARSET,
		OUT_CHARACTER_PRECIS, CLIP_CHARACTER_PRECIS, DEFAULT_QUALITY,
		FF_DONTCARE, TEXT("΢���ź�")
	);
	if (!useful) {
		switch (uMsg)
		{
		case WM_CREATE:
			bigger = 1;
			hmenu = createmainMenu(hwnd);
			SetMenu(hwnd, hmenu);
			edit_bg = CreateWindow("edit", NULL, WS_CHILD | WS_VISIBLE | WS_BORDER, 55, 20, 90, 20, hwnd, NULL, NULL, NULL);
			edit_ed = CreateWindow("edit", NULL, WS_CHILD | WS_VISIBLE | WS_BORDER, 55, 50, 90, 20, hwnd, NULL, NULL, NULL);
			button1 = CreateWindow("button", "�ٻ���", WS_CHILD | WS_VISIBLE | WS_BORDER, 20, 80, 60, 20, hwnd, NULL, NULL, NULL);
			button2 = CreateWindow("button", "���·", WS_CHILD | WS_VISIBLE | WS_BORDER, 80, 80, 60, 20, hwnd, NULL, NULL, NULL);
			button_big = CreateWindow("button", " + ", WS_CHILD | WS_VISIBLE | WS_BORDER, 20, 110, 40, 20, hwnd, NULL, NULL, NULL);
			button_small = CreateWindow("button", " - ", WS_CHILD | WS_VISIBLE | WS_BORDER, 80, 110, 40, 20, hwnd, NULL, NULL, NULL);
			label1 = CreateWindow("static", "���", WS_CHILD | WS_VISIBLE | WS_BORDER, 10, 20, 40, 20, hwnd, NULL, NULL, NULL);
			label2 = CreateWindow("static", "�յ�", WS_CHILD | WS_VISIBLE | WS_BORDER, 10, 50, 40, 20, hwnd, NULL, NULL, NULL);
			edit_seek = CreateWindow("edit", NULL, WS_CHILD | WS_VISIBLE | WS_BORDER, 30, 140, 90, 20, hwnd, NULL, NULL, NULL);
			button_seek = CreateWindow("button", "��ѯ", WS_CHILD | WS_VISIBLE | WS_BORDER, 30, 170, 90, 20, hwnd, NULL, NULL, NULL);
			SendMessage(label1, WM_SETFONT, (WPARAM)hFont, NULL);
			SendMessage(label2, WM_SETFONT, (WPARAM)hFont, NULL);
			SendMessage(button1, WM_SETFONT, (WPARAM)hFont, NULL);
			SendMessage(button2, WM_SETFONT, (WPARAM)hFont, NULL);
			SendMessage(button_big, WM_SETFONT, (WPARAM)hFont, NULL);
			SendMessage(button_small, WM_SETFONT, (WPARAM)hFont, NULL);
			SendMessage(edit_bg, WM_SETFONT, (WPARAM)hFont, NULL);
			SendMessage(edit_ed, WM_SETFONT, (WPARAM)hFont, NULL);
			SendMessage(edit_seek, WM_SETFONT, (WPARAM)hFont, NULL);
			SendMessage(button_seek, WM_SETFONT, (WPARAM)hFont, NULL);
			return 0;
		case WM_COMMAND:
			switch ((LOWORD(wParam)))
			{
			case IMPORTMENU:
				char szBuffer[1024] = { 0 };
				OPENFILENAME ofn = { 0 };
				ofn.lStructSize = sizeof(ofn);
				ofn.lpstrFilter = "*.*\0*.*\0\0";//Ҫѡ����ļ���׺   
				ofn.lpstrInitialDir = "D:\\";//Ĭ�ϵ��ļ�·��   
				ofn.lpstrFile = szBuffer;//����ļ��Ļ�����   
				ofn.nMaxFile = sizeof(szBuffer) / sizeof(*szBuffer);
				ofn.nFilterIndex = 0;
				ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST | OFN_EXPLORER;//��־����Ƕ�ѡҪ����OFN_ALLOWMULTISELECT  
				BOOL bSel = GetOpenFileName(&ofn);
				//bj = new City("szBuffer");
				try {
					useful = bj.readmap(szBuffer);
				}
				catch (Errortype e) {
					switch (e.get())
					{
					case 1:
						MessageBoxA(NULL, "�ļ�����", "������Ϣ", MB_OK);
						break;
					case 2:
						MessageBoxA(NULL, "վ�����", "������Ϣ", MB_OK);
						break;
					case 3:
						MessageBoxA(NULL, "��·����", "������Ϣ", MB_OK);
						break;
					default:
						break;
					}
				}
				if (useful) {
					InvalidateRect(hwnd, NULL, false);
				}
				return 0;
			}
		}
	}
	else {
		switch (uMsg)
		{
		case WM_LBUTTONDOWN:
			p.x = LOWORD(lParam);
			p.y = HIWORD(lParam);
			return 0;
		case WM_PAINT:
			hdc = BeginPaint(hwnd, &ps);
			RECT rt;
			GetClientRect(hwnd, &rt);//�Ծ��α�����ֵΪ���ھ���
			HDC hDCMem;
			HBITMAP hBitmap;
			HBRUSH hBrush, brush_grey;
			hBrush = CreateSolidBrush(GetBkColor(hdc));
			brush_grey = CreateSolidBrush(RGB(255, 255, 255));
			hDCMem = CreateCompatibleDC(hdc);
			hBitmap = CreateCompatibleBitmap(hdc, rt.right - rt.left, rt.bottom - rt.top);
			SelectObject(hDCMem, hBitmap);
			FillRect(hDCMem, &rt, hBrush);
			DeleteObject(hBrush);

			DrawLine(hDCMem);
			DrawSta(hDCMem);
			if (way[0] != 0)
			{
				paintway(hDCMem, way);
				printsta(hdc);
			}
			paintsta(hDCMem);

			BitBlt(hdc, 150, 0, rt.right - rt.left, rt.bottom - rt.top, hDCMem, 0, 0, SRCCOPY);
			//ɾ����Դ
			DeleteObject(hBitmap);
			DeleteDC(hDCMem);
			EndPaint(hwnd, &ps);
			return 0;
		case WM_MOUSEMOVE:
			if (wParam & MK_LBUTTON)//ֻ��������϶�����Ϣ
			{
				if (mx + LOWORD(lParam) - p.x <= 0 && (MAXX * bigger + mx + LOWORD(lParam) - p.x) >= MAXX) {
					mx += LOWORD(lParam) - p.x;
				}
				if (my + HIWORD(lParam) - p.y <= 0 && (MAXY * bigger + my + HIWORD(lParam) - p.y) >= MAXY) {
					my += HIWORD(lParam) - p.y;
				}
				InvalidateRect(hwnd, NULL, false);
				p.x = LOWORD(lParam);
				p.y = HIWORD(lParam);
			}
			return 0;
		case WM_COMMAND:
			switch ((LOWORD(wParam)))
			{
			case POPMENU1:
				bg_sta = choosedsta;
				SetWindowText(edit_bg, bj.id2str(choosedsta));
				way[0] = 0;
				seektime++;
				InvalidateRect(hwnd, NULL, false);
				return 0;
			case POPMENU2:
				ed_sta = choosedsta;
				SetWindowText(edit_ed, bj.id2str(choosedsta));
				way[0] = 0;
				seektime++;
				InvalidateRect(hwnd, NULL, false);
				return 0;
			case IMPORTMENU:
				char szBuffer[1024] = { 0 };
				OPENFILENAME ofn = { 0 };
				ofn.lStructSize = sizeof(ofn);
				ofn.lpstrFilter = "*.*\0*.*\0\0";//Ҫѡ����ļ���׺   
				ofn.lpstrInitialDir = "F:\\";//Ĭ�ϵ��ļ�·��   
				ofn.lpstrFile = szBuffer;//����ļ��Ļ�����   
				ofn.nMaxFile = sizeof(szBuffer) / sizeof(*szBuffer);
				ofn.nFilterIndex = 0;
				ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST | OFN_EXPLORER;//��־����Ƕ�ѡҪ����OFN_ALLOWMULTISELECT  
				BOOL bSel = GetOpenFileName(&ofn);
				try {
					useful = bj.readmap(szBuffer);
				}
				catch (Errortype e) {
					switch (e.get())
					{
					case 1:
						MessageBoxA(NULL, "�ļ�����", "������Ϣ", MB_OK);
						break;
					case 2:
						MessageBoxA(NULL, "վ�����", "������Ϣ", MB_OK);
						break;
					case 3:
						MessageBoxA(NULL, "��·����", "������Ϣ", MB_OK);
						break;
					default:
						break;
					}
				}
				if (useful) {
					InvalidateRect(hwnd, NULL, false);
				}
				return 0;
			}
			if ((HWND)lParam == button_big && (HIWORD(wParam) == BN_CLICKED)) {
				if (bigger < 2) {
					bigger += 0.5;
					InvalidateRect(hwnd, NULL, false);
				}
				return 0;
			}
			if ((HWND)lParam == button_small && (HIWORD(wParam) == BN_CLICKED)) {
				if (bigger > 1) {
					bigger -= 0.5;
					if (MAXX*bigger + mx < MAXX) {
						mx = MAXX*bigger - MAXX;
					}
					if (MAXY*bigger + my < MAXY) {
						my = MAXY*bigger - MAXY;
					}
					if (mx > 0) {
						mx = 0;
					}
					if (my > 0) {
						my = 0;
					}
					InvalidateRect(hwnd, NULL, false);
				}
				return 0;
			}
			if ((HWND)lParam == button1 && (HIWORD(wParam) == BN_CLICKED)) {
				num_bg = GetWindowText(edit_bg, s1, 30);
				num_ed = GetWindowText(edit_ed, s2, 30);
				if (num_bg == 0) {
					MessageBox(NULL, "���վ����Ϊ��", "������Ϣ", MB_OK);
					return 0;
				}
				if (num_bg == 0) {
					MessageBox(NULL, "�յ�վ����Ϊ��", "������Ϣ", MB_OK);
					return 0;
				}
				if (bj.str2id(s1) == -1) {
					MessageBox(NULL, "���վ������", "������Ϣ", MB_OK);
					return 0;
				}
				if (bj.str2id(s2) == -1) {
					MessageBox(NULL, "�յ�վ������", "������Ϣ", MB_OK);
					return 0;
				}
				findway(s1, s2, 2);
				seektime++;
				fillprintrect(hwnd);
				HANDLE handle = CreateThread(NULL, 0, flash, NULL, 0, NULL);
				InvalidateRect(hwnd, NULL, false);
			}
			if ((HWND)lParam == button2 && (HIWORD(wParam) == BN_CLICKED)) {
				num_bg = GetWindowText(edit_bg, s1, 30);
				num_ed = GetWindowText(edit_ed, s2, 30);
				if (num_bg == 0) {
					MessageBox(NULL, "���վ����Ϊ��", "������Ϣ", MB_OK);
					return 0;
				}
				if (num_bg == 0) {
					MessageBox(NULL, "�յ�վ����Ϊ��", "������Ϣ", MB_OK);
					return 0;
				}
				if (bj.str2id(s1) == -1) {
					MessageBox(NULL, "���վ������", "������Ϣ", MB_OK);
					return 0;
				}
				if (bj.str2id(s2) == -1) {
					MessageBox(NULL, "�յ�վ������", "������Ϣ", MB_OK);
					return 0;
				}
				findway(s1, s2, 1);
				seektime++;
				fillprintrect(hwnd);
				HANDLE handle = CreateThread(NULL, 0, flash, NULL, 0, NULL);
				InvalidateRect(hwnd, NULL, false);
			}
			if ((HWND)lParam == button_seek && (HIWORD(wParam) == BN_CLICKED)) {
				num = GetWindowText(edit_seek, s1, 30);
				if (seek(s1) == 0)
				{
					MessageBox(hwnd, "��ѯ���ݲ�����", "������Ϣ", MB_OK);
				}

				InvalidateRect(hwnd, NULL, false);
			}
			return 0;
		case WM_RBUTTONDOWN:
			pt.y = HIWORD(lParam);
			pt.x = LOWORD(lParam);
			p = point2point(pt.x, pt.y);
			if (p.x == 0 && p.y == 0)
			{
				return 0;
			}
			pt.x = p.x;
			pt.y = p.y;
			hTrack = createPopMenu(hwnd);
			hSon = GetSubMenu(hTrack, 0);
			ClientToScreen(hwnd, &pt);
			TrackPopupMenu(hSon, TPM_LEFTBUTTON | TPM_RIGHTALIGN, pt.x + RMENU, pt.y, 0, hwnd, NULL);
			return 0;
		case WM_ERASEBKGND:
			return true;
		}
	}
	if (uMsg == WM_CLOSE) {
		PostQuitMessage(0);
		return 0;
	}
	return DefWindowProc(hwnd, uMsg, wParam, lParam);                         //δ��������Ϣͨ��DefWindowProc��������ϵͳ���� 
}

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR     lpCmdLine, int       nCmdShow) {
	WNDCLASS WndClass;                                          
	WndClass.cbClsExtra = 0;                                       
	WndClass.cbWndExtra = 0;                                      
	WndClass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);   //������ˢ
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);                 //��� 
	WndClass.hIcon = LoadIcon(NULL, IDI_ERROR);                     //����ͼ�� 
	WndClass.hInstance = hInstance;                                
	WndClass.lpfnWndProc = WinSunProc;                             
	WndClass.lpszClassName = "windowclass";                        
	WndClass.lpszMenuName = NULL;                                 
	WndClass.style = 0;
	if (!RegisterClass(&WndClass))
	{
		MessageBox(NULL, "����ע��ʧ��!", "Hello Win", 0);
		return 0;
	}
	HWND hwnd;                       
	hwnd = CreateWindow("windowclass", "first windows", WS_OVERLAPPEDWINDOW, 0, 0, 600, 400, NULL, NULL, hInstance, NULL); //��������
	ShowWindow(hwnd, SW_SHOWNORMAL);                          
	UpdateWindow(hwnd);                                       
	MSG msg;                                                 
	while (GetMessage(&msg, NULL, 0, 0))                        
	{
		TranslateMessage(&msg);                              
		DispatchMessage(&msg);                                  
	}
	return 0;
}

void DrawSta(HDC hdc)
{
	int i = 1;
	int size = 5;
	Point p;
	HPEN pen;
	int lineid;
	HBRUSH brush = CreateSolidBrush(RGB(255, 255, 255));
	SelectObject(hdc, brush);
	while (i <= bj.getstanum()) {
		lineid = bj.sta2line(i);
		if (lineid == -1) {
			pen = CreatePen(PS_SOLID, 2.5 * bigger, RGB(0,0,0));
		}
		else {
			pen = CreatePen(PS_SOLID, 2.5 * bigger, RGB(colors[lineid][0], colors[lineid][1], colors[lineid][2]));
		}
		SelectObject(hdc, pen);
		p = bj.getloc(i);
		Ellipse(hdc, (p.x - size)*bigger + mx, (p.y + size)*bigger + my, (p.x + size)*bigger + mx, (p.y - size)*bigger + my);
		i++;
		DeleteObject(pen);
	}
	DeleteObject(brush);
}

void DrawLine(HDC hdc)
{
	int i = 0;
	int size = 5;
	int j,m;
	Point p;
	int *way;
	HPEN pen;
	while (i < bj.getlinenum()) {
		pen = CreatePen(PS_SOLID, 5 * bigger, RGB(colors[i][0], colors[i][1], colors[i][2]));
		SelectObject(hdc, pen);
		way = bj.getline(i);
		j = 0;
		for (j = 0; way[j] != -1; j++) {
			for (m = 0; way[m] != -1; m++) {
				if (bj.linked(way[j], way[m])) {
					p = bj.getloc(way[j]);
					MoveToEx(hdc, p.x*bigger + mx, p.y*bigger + my, NULL);
					p = bj.getloc(way[m]);
					LineTo(hdc, p.x*bigger + mx, p.y*bigger + my);
				}
			}
		}
		i++;
		delete(way);
		DeleteObject(pen);
	}
}

void findway(char *s1, char *s2, int type)
{
	int *w;
	int i;
	if (type == 1)
	{
		w = bj.shortestway(s1, s2);
	}
	else if (type == 2)
	{
		w = bj.least_transfer(s1, s2);
	}
	else {
		return;
	}
	if (w == NULL)
	{
		way[0] = 0;
		return;
	}
	i = 0;
	while (w[i] != bj.getstanum() + 1)
	{
		way[i] = w[i];
		i++;
	}
	way[i] = bj.getstanum() + 1;
}

void paintway(HDC hdc, int *way)
{
	int i;
	int size = 5;
	Point p,pre;
	pre = { -1,-1 };
	HPEN pen = CreatePen(PS_SOLID, 3*bigger, RGB(0x0, 0x0, 0x80));
	HBRUSH brush = CreateSolidBrush(RGB(0x7c, 0xff, 0x0));
	SelectObject(hdc, pen);
	SelectObject(hdc, brush);
	i = 0;
	while (way[i] != bj.getstanum()+1){
		if (way[i] > 0){
			p = bj.getloc(way[i]);
			if (pre.x != -1) {
				MoveToEx(hdc, pre.x*bigger + mx, pre.y*bigger + my, NULL);
				LineTo(hdc, p.x*bigger + mx, p.y*bigger + my);
			}
			pre.x = p.x;
			pre.y = p.y;
		}
		i++;
	}
	DeleteObject(pen);
	pen = CreatePen(PS_SOLID, 2.5*bigger, RGB(0x0, 0x0, 0x80));
	SelectObject(hdc,pen);
	i = 0;
	while (way[i] != bj.getstanum() + 1) {
		if (way[i] > 0)
		{
			p = bj.getloc(way[i]);
			if (expandid == way[i]) {
				size *= 2;
				Ellipse(hdc, (p.x - size)*bigger + mx, (p.y + size)*bigger + my, (p.x + size)*bigger + mx, (p.y - size)*bigger + my);
				size /= 2;
			}
			else {
				Ellipse(hdc, (p.x - size)*bigger + mx, (p.y + size)*bigger + my, (p.x + size)*bigger + mx, (p.y - size)*bigger + my);
			}
		}
		i++;
	}
	DeleteObject(pen);
	DeleteObject(brush);

}

HMENU createPopMenu(HWND hwnd)
{
	HMENU hMenu = CreateMenu();
	HMENU hPop = CreateMenu();
	AppendMenu(hPop, MF_STRING, 200, TEXT("��Ϊ���"));
	AppendMenu(hPop, MF_STRING, 201, TEXT("��Ϊ�յ�"));
	AppendMenu(hMenu, MF_POPUP, (UINT_PTR)hPop, TEXT("Pop"));
	return  hMenu;

}

HMENU createmainMenu(HWND hwnd)
{
	HMENU hmenu = CreateMenu();
	HMENU hPopMenu = CreateMenu();
	AppendMenu(hmenu, MF_POPUP, (UINT_PTR)hPopMenu, "file");
	AppendMenu(hPopMenu, MF_STRING, IMPORTMENU, "import");
	return hmenu;
}

Point point2point(int x, int y)
{
	Point p;
	int error = 7*bigger;
	for (int i = 1; i <= bj.getstanum(); i++) {
		p = bj.getloc(i);
		p.x = p.x*bigger + mx;
		p.y = p.y*bigger + my;
		if (p.x - x + RMENU < error && p.x - x + RMENU > -error && p.y - y < error && p.y - y > -error) {
			choosedsta = i;
			return p;
		}
	}
	p.x = 0;
	p.y = 0;
	return p;
}

int seek(char *s)
{
	int *w;
	int i,id;
	w = bj.printline(s);
	if (w != NULL)
	{
		i = 0;
		while (w[i] != bj.getstanum() + 1)
		{
			way[i] = w[i];
			i++;
		}
		way[i] = bj.getstanum() + 1;
		return 1;
	}
	else {
		id = bj.str2id(s);
		if (id == -1) {
			return 0;
		}
		seek_sta = id;
		return 1;
	}
}

void paintsta(HDC hdc)
{
	Point pp;
	int size = 7;
	HPEN pen = CreatePen(PS_SOLID, 2.5*bigger, RGB(0x0, 0x0, 0x80));
	HBRUSH brush_bg = CreateSolidBrush(RGB(0xee, 0xee, 0x0));
	HBRUSH brush_ed = CreateSolidBrush(RGB(0xcd, 0x37, 0x0));
	SelectObject(hdc, pen);
	pp = bj.getloc(bg_sta);
	if (pp.x != 0) {
		SelectObject(hdc, brush_bg);
		Ellipse(hdc, (pp.x - size)*bigger + mx, (pp.y + size)*bigger + my, (pp.x + size)*bigger + mx, (pp.y - size)*bigger + my);
		DeleteObject(brush_bg);
	}
	pp = bj.getloc(ed_sta);
	if (pp.x != 0) {
		SelectObject(hdc, brush_ed);
		Ellipse(hdc, (pp.x - size)*bigger + mx, (pp.y + size)*bigger + my, (pp.x + size)*bigger + mx, (pp.y - size)*bigger + my);
		DeleteObject(brush_ed);
	}
	pp = bj.getloc(seek_sta);
	if (pp.x != 0) {
		Ellipse(hdc, (pp.x - size)*bigger + mx, (pp.y + size)*bigger + my, (pp.x + size)*bigger + mx, (pp.y - size)*bigger + my);
	}
	DeleteObject(pen);
}

void printsta(HDC hdc)
{
	int offset = 0;
	int offsetx = 0;
	int size = 15;
	int i = 0;
	int sta = 0, transfer = 0;
	string str1("����վ���� ");
	string str2("���˴����� ");
	char stmp[10];
	char *s;
	char s1[10] = "ת��";
	char sa[40];
	static HFONT hFont = CreateFont(-12, -6, 0, 0, 400 ,
		FALSE/*б��?*/, FALSE/*�»���?*/, FALSE/*ɾ����?*/, DEFAULT_CHARSET,
		OUT_CHARACTER_PRECIS, CLIP_CHARACTER_PRECIS, DEFAULT_QUALITY,
		FF_DONTCARE, TEXT("΢���ź�")
	);;
	while (way[i] != bj.getstanum() + 1) {
		SelectObject(hdc, hFont);
		if (i == 25) {
			offset = 0;
			offsetx = 80;
		}
		if (way[i] > 0) {
			s = bj.id2str(way[i]);
			TextOut(hdc, 10 + offsetx, 280 + offset,s,strlen(s));
			sta++;
		}
		else {
			s = bj.id2line(-way[i]);
			strcpy(sa, s1);
			strcpy(sa + strlen(s1), s);
			TextOut(hdc, 10 + offsetx, 280 + offset, sa, strlen(sa));
			transfer++;
		}
		i++;
		offset += size;
	}
	itoa(sta, stmp, 10);
	string tmp(str1 + stmp);
	TextOut(hdc, 20, 210, tmp.c_str(), tmp.size());
	itoa(transfer, stmp, 10);
	tmp = string(str2 + stmp);
	TextOut(hdc, 20, 240, tmp.c_str(), tmp.size());
}

DWORD WINAPI flash(LPVOID pM)
{
	int exps[5] = { 1.2,1.7,2,1.7,1.2 };
	int i = 0, exp = 0;
	int size = 10;
	Point p = { 0,0 };
	HDC hdc;
	int time = seektime;
	HPEN pen = CreatePen(PS_SOLID, 2.5*bigger, RGB(0x0, 0x0, 0x80));
	HBRUSH brush = CreateSolidBrush(RGB(0x7c, 0xff, 0x0));
	SelectObject(HDC(pM), pen);
	SelectObject(HDC(pM), brush);
	if (way[0] == 0) {
		return 0;
	}
	else {
		hdc = GetDC(HWND(pM));
		while (way[i] != bj.getstanum()+1) {
			if (way[i] <= 0) {
				i++;
				continue;
			}
			if (seektime != time) {
				break;
			}
			expandid = way[i];
			p = bj.getloc(way[i]);
			InvalidateRect(HWND(pM), NULL, false);
			Sleep(300);
			i++;

		}
	}
	expandid = 0;
	InvalidateRect(HWND(pM), NULL, false);
	return 0;
}

void fillprintrect(HWND hwnd) {
	HBRUSH brush = CreateSolidBrush(RGB(255,255,255));
	HDC hdc;
	hdc = GetDC(hwnd);
	SelectObject(hdc, brush);
	RECT rect;
	rect.bottom = MAXX;
	rect.top = 200;
	rect.left = 0;
	rect.right = 150;
	FillRect(hdc, &rect, brush);
	ReleaseDC(hwnd, hdc);
}